namespace Warehouse_Project
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Product_ImpPermission
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProdPermission_ID { get; set; }

        public int? ImpPermission_ID { get; set; }

        public int? Product_Code { get; set; }

        public int? Product_Count { get; set; }

        [Column(TypeName = "date")]
        public DateTime Production_Date { get; set; }

        [Column(TypeName = "date")]
        public DateTime Expire_Date { get; set; }

        public virtual ImportPermission ImportPermission { get; set; }

        public virtual Product Product { get; set; }
    }
}
