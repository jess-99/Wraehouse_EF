namespace Warehouse_Project
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ProductTransfer")]
    public partial class ProductTransfer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Transfer_ID { get; set; }

        public int FromStore_ID { get; set; }

        public int ToStore_ID { get; set; }

        public int? Supplier_ID { get; set; }

        public int? Product_Code { get; set; }

        public int? Product_Count { get; set; }

        [Column(TypeName = "date")]
        public DateTime Production_Date { get; set; }

        [Column(TypeName = "date")]
        public DateTime Expire_Date { get; set; }

        [Column(TypeName = "date")]
        public DateTime Transfer_Date { get; set; }

        public virtual Product Product { get; set; }

        public virtual Store Store { get; set; }

        public virtual Supplier Supplier { get; set; }

        public virtual Store Store1 { get; set; }
    }
}
