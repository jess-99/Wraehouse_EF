namespace Warehouse_Project
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Supplier
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Supplier()
        {
            ExportPermissions = new HashSet<ExportPermission>();
            ImportPermissions = new HashSet<ImportPermission>();
            ProductTransfers = new HashSet<ProductTransfer>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Supplier_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Supplier_Name { get; set; }

        [StringLength(50)]
        public string Supplier_Fax { get; set; }

        [Required]
        [StringLength(50)]
        public string Supplier_Phone { get; set; }

        [StringLength(50)]
        public string Supplier_Email { get; set; }

        [StringLength(50)]
        public string Supplier_Website { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ExportPermission> ExportPermissions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ImportPermission> ImportPermissions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProductTransfer> ProductTransfers { get; set; }
    }
}
