﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Warehouse_Project
{
    public partial class Processing : Form
    {
        EFModel Ent = new EFModel();
        int ProductCount;
        int oldCount;
        List<int> count = new List<int>();
        int fromCount;
        int toCount;
        public Processing()
        {
            InitializeComponent();
            UpdateComboBox();
            LoadListViews();

        }

        #region update ComboBox
        //update combobox for each point in the task
        #endregion

        public void UpdateComboBox()
        {
            //store combobox
            var store = from s in Ent.Stores
                        select s.Store_ID;
            foreach (var st in store)
            {
                comboBox1.Items.Add(st);
            }

            //products combobox
            var product = from p in Ent.Products
                          select p.Product_Name;
            foreach (var pr in product)
            {
                comboBox2.Items.Add(pr);
            }

            //customers combobox
            var customer = from c in Ent.Customers
                           select c.Customer_ID;
            foreach (var cust in customer)
            {
                comboBox3.Items.Add(cust);
            }

            //supplier combobox
            var supplier = from sup in Ent.Suppliers
                           select sup.Supplier_ID;
            foreach (var supp in supplier)
            {
                comboBox4.Items.Add(supp);
            }

            //import permission
            var import = from i in Ent.ImportPermissions
                         select i.ImpPermission_ID;
            foreach (var imp in import)
            {
                comboBox5.Items.Add(imp);
            }

            //product code
            var productCode = from p in Ent.Products
                              select p.Product_Code;
            foreach (var pr in productCode)
            {
                comboBox8.Items.Add(pr);
                comboBox9.Items.Add(pr);
            }

            //export permission
            var export = from e in Ent.ExportPermissions
                         select e.ExpPermission_ID;
            foreach (var ex in export)
            {
                comboBox6.Items.Add(ex);
            }

            //product transfer
            var transfer = from t in Ent.ProductTransfers
                           select t.Transfer_ID;
            foreach (var pt in transfer)
            {
                comboBox7.Items.Add(pt);
            }
        }


        #region Createlistview 
        //Create listview1 & lisyview2 columns
        #endregion

        public void LoadListViews()
        {
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.Columns.Add("Product_Code", 100);
            listView1.Columns.Add("Product_Countity", 100);

            listView2.View = View.Details;
            listView2.GridLines = true;
            listView2.FullRowSelect = true;
            listView2.Columns.Add("Product_Code", 100);
            listView2.Columns.Add("Product_Countity", 100);
        }

        #region store combobox 
        // when selecting item in combobox it feels the data in controllors with values coresponding to store name
        #endregion
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID = int.Parse(comboBox1.Text);
            Store store = Ent.Stores.Find(ID);
            if(store != null)
            {
                textBox1.Text = store.Store_ID.ToString();
                textBox2.Text = store.Store_Name;
                textBox3.Text = store.Store_Add;
                textBox4.Text = store.Store_Manager;
            }
        }

        #region add store
        // the buttons takes the value in each control in the form and add its data to store table
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            Store store = new Store();
            store.Store_ID = int.Parse(textBox1.Text);
            store.Store_Name = textBox2.Text;
            store.Store_Add = textBox3.Text;
            store.Store_Manager = textBox4.Text;
            var AvailableId = (from s in Ent.Stores where s.Store_ID == store.Store_ID select s).FirstOrDefault();
            if(AvailableId == null)
            {
                Ent.Stores.Add(store);
                Ent.SaveChanges();
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
                MessageBox.Show("Store Added");
                comboBox1.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update store
        // the buttons takes the value in each control in the form and update the changed fields in the table
        #endregion
        private void button2_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox1.Text);
            Store store = (Ent.Stores.Where(s => s.Store_ID == ID).Select(s => s)).FirstOrDefault();
            if (store != null)
            {
                store.Store_Name = textBox2.Text;
                store.Store_Add = textBox3.Text;
                store.Store_Manager = textBox4.Text;
                Ent.SaveChanges();
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
                MessageBox.Show("Store Updated");
                comboBox1.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region product combobox 
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string name = comboBox2.Text;
            var ProductCode = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            textBox5.Text = ProductCode.ToString();
            int ID = int.Parse(textBox5.Text);
            Product product = Ent.Products.Find(ID);
            if (product != null)
            {
                textBox6.Text = product.Product_Name;
                dateTimePicker1.Value = product.Production_Date;
                dateTimePicker2.Value = product.Expire_Date;
                ItemMeasurement measurement = new ItemMeasurement();
                foreach (var item in panel1.Controls)
                {
                    if (item.GetType() == typeof(CheckBox))
                    {
                        var checkBoxCtrl = (CheckBox)item;
                        if (checkBoxCtrl.Text == measurement.Measure)
                        {
                           checkBoxCtrl.Checked = true;
                        }
                    }
                }
                var measure = Ent.ItemMeasurements.Where(m => m.Product_Code == ProductCode).Select(m => m.Measure);
                foreach (var item in measure)
                {
                    listBox1.Items.Add(item);

                }
            }
        }

        #region add product
        // the buttons takes the value in each control in the form and add its data to product and itemmeasurement table
        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            product.Product_Code = int.Parse(textBox5.Text);
            product.Product_Name = textBox6.Text;
            product.Production_Date = dateTimePicker1.Value;
            product.Expire_Date = dateTimePicker2.Value;
            var AvailableId = (from p in Ent.Products where p.Product_Code == product.Product_Code select p).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.Products.Add(product);
                Ent.SaveChanges();
                foreach (var item in panel1.Controls)
                {
                    if(item.GetType() == typeof(CheckBox))
                    {
                        var checkBoxCtrl = (CheckBox)item;
                        if (checkBoxCtrl.Checked)
                        {
                            ItemMeasurement measurement = new ItemMeasurement();
                            measurement.Product_Code = int.Parse(textBox5.Text);
                            measurement.Measure = checkBoxCtrl.Text;
                            Ent.ItemMeasurements.Add(measurement);
                            Ent.SaveChanges();
                        }
                    }
                }
                textBox5.Text = textBox6.Text = "";
                dateTimePicker1.Value = dateTimePicker2.Value = DateTime.Now;
                MessageBox.Show("Product Added");
                comboBox2.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update product
        // the buttons takes the value in each control in the form and update the changed fields in the table
        #endregion
        private void button4_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox5.Text);
            Product product = (Ent.Products.Where(p => p.Product_Code == ID).Select(p => p)).FirstOrDefault();
            if (product != null)
            {
                product.Product_Name = textBox6.Text;
                product.Production_Date = dateTimePicker1.Value;
                product.Expire_Date = dateTimePicker2.Value;
                Ent.SaveChanges();
                #region try
                //ItemMeasurement measurement = new ItemMeasurement();
                //foreach (var item in panel1.Controls)
                //{
                //    if (item.GetType() == typeof(CheckBox))
                //    {
                //        var checkBoxCtrl = (CheckBox)item;
                //        if (checkBoxCtrl.Checked)
                //        {
                //            measurement.Product_Code = int.Parse(textBox5.Text);
                //            measurement.Measure = checkBoxCtrl.Text;
                //        }
                //        Ent.ItemMeasurements.Add(measurement);
                //        Ent.SaveChanges();
                //    }
                //}
                #endregion
                textBox5.Text = textBox6.Text = "";
                dateTimePicker1.Value = dateTimePicker2.Value = DateTime.Now;
                MessageBox.Show("Product Updated");
                comboBox2.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region customer combobox 
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID = int.Parse(comboBox3.Text);
            Customer customer = Ent.Customers.Find(ID);
            if (customer != null)
            {
                textBox8.Text = customer.Customer_ID.ToString();
                textBox9.Text = customer.Customer_Name;
                textBox10.Text = customer.Customer_Fax;
                textBox11.Text = customer.Customer_Phone;
                textBox12.Text = customer.Customer_Email;
                textBox13.Text = customer.Customer_Website;
            }
        }

        #region add customer
        // the buttons takes the value in each control in the form and add its data to customer table
        #endregion
        private void button5_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.Customer_ID = int.Parse(textBox8.Text);
            customer.Customer_Name = textBox9.Text;
            customer.Customer_Fax = textBox10.Text;
            customer.Customer_Phone = textBox11.Text;
            customer.Customer_Email = textBox12.Text;
            customer.Customer_Website = textBox13.Text;
            var AvailableId = (from c in Ent.Customers where c.Customer_ID == customer.Customer_ID select c).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.Customers.Add(customer);
                Ent.SaveChanges();
                textBox8.Text = textBox9.Text = textBox10.Text = textBox11.Text = textBox12.Text = textBox13.Text = "";
                MessageBox.Show("Customer Added");
                comboBox3.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update customer
        // the buttons takes the value in each control in the form and update the changed fields in the table
        #endregion
        private void button6_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox8.Text);
            Customer customer = (Ent.Customers.Where(c => c.Customer_ID == ID).Select(c => c)).FirstOrDefault();
            if (customer != null)
            {
                customer.Customer_Name = textBox9.Text;
                customer.Customer_Fax = textBox10.Text;
                customer.Customer_Phone = textBox11.Text;
                customer.Customer_Email = textBox12.Text;
                customer.Customer_Website = textBox13.Text;
                Ent.SaveChanges();
                textBox8.Text = textBox9.Text = textBox10.Text = textBox11.Text = textBox12.Text = textBox13.Text = "";
                MessageBox.Show("Customer Updated");
                comboBox3.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region supplier combobox 
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID = int.Parse(comboBox4.Text);
            Supplier supplier = Ent.Suppliers.Find(ID);
            if (supplier != null)
            {
                textBox14.Text = supplier.Supplier_ID.ToString();
                textBox15.Text = supplier.Supplier_Name;
                textBox16.Text = supplier.Supplier_Fax;
                textBox17.Text = supplier.Supplier_Phone;
                textBox18.Text = supplier.Supplier_Email;
                textBox19.Text = supplier.Supplier_Website;
            }
        }

        #region add supplier
        // the buttons takes the value in each control in the form and add its data to supplier table
        #endregion
        private void button7_Click(object sender, EventArgs e)
        {
            Supplier supplier = new Supplier();
            supplier.Supplier_ID = int.Parse(textBox14.Text);
            supplier.Supplier_Name = textBox15.Text;
            supplier.Supplier_Fax = textBox16.Text;
            supplier.Supplier_Phone = textBox17.Text;
            supplier.Supplier_Email = textBox18.Text;
            supplier.Supplier_Website = textBox19.Text;
            var AvailableId = (from s in Ent.Suppliers where s.Supplier_ID == supplier.Supplier_ID select s).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.Suppliers.Add(supplier);
                Ent.SaveChanges();
                textBox14.Text = textBox15.Text = textBox16.Text = textBox17.Text = textBox18.Text = textBox19.Text = "";
                MessageBox.Show("Supplier Added");
                comboBox4.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update supplier
        // the buttons takes the value in each control in the form and update the changed fields in the table
        #endregion
        private void button8_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox14.Text);
            Supplier supplier = (Ent.Suppliers.Where(s => s.Supplier_ID == ID).Select(s => s)).FirstOrDefault();
            if (supplier != null)
            {
                supplier.Supplier_Name = textBox15.Text;
                supplier.Supplier_Fax = textBox16.Text;
                supplier.Supplier_Phone = textBox17.Text;
                supplier.Supplier_Email = textBox18.Text;
                supplier.Supplier_Website = textBox19.Text;
                Ent.SaveChanges();
                textBox14.Text = textBox15.Text = textBox16.Text = textBox17.Text = textBox18.Text = textBox19.Text = "";
                MessageBox.Show("Supllier Updated");
                comboBox4.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region import permission combobox
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ImportID = int.Parse(comboBox5.Text);
            ImportPermission import = Ent.ImportPermissions.Find(ImportID);
            if(import != null)
            {
                textBox20.Text = import.ImpPermission_ID.ToString();
                textBox21.Text = import.Store_ID.ToString();
                textBox22.Text = import.Supplier_ID.ToString();
                dateTimePicker3.Value = import.Permission_Date;
                Product_ImpPermission product_Imp = (Ent.Product_ImpPermission.Where(i => i.ImpPermission_ID == ImportID).Select(i => i)).FirstOrDefault(); 
                textBox26.Text = product_Imp.Product_Count.ToString();
                dateTimePicker4.Value = product_Imp.Production_Date;
                dateTimePicker5.Value = product_Imp.Expire_Date;
            }
        }

        #region import product code combobox
        // when selected it shows the countity coursponding product
        #endregion
        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            int code = int.Parse(comboBox8.Text);
            int id = int.Parse(textBox21.Text);
            var count = (from store in Ent.ImportPermissions
                         from pc in Ent.Product_ImpPermission
                         where store.ImpPermission_ID == pc.ImpPermission_ID
                         where store.Store_ID == id
                         where pc.Product_Code == code
                         select pc.Product_Count).FirstOrDefault();
            textBox26.Text = count.ToString();
        }

        #region fill import listview
        // fill listview with product code and its countity
        #endregion
        private void button16_Click(object sender, EventArgs e)
        {

            string[] arr = new string[10];
            ListViewItem item;
            //add items to ListView
            arr[0] = comboBox8.Text;
            arr[1] = textBox26.Text;
            item = new ListViewItem(arr);
            listView1.Items.Add(item);
        }

        #region add import permission
        //enter products in specific store with the desired countity the count number then will be added to the total count of that product
        #endregion
        private void button9_Click(object sender, EventArgs e)
        {
            ImportPermission import = new ImportPermission();
            import.ImpPermission_ID = int.Parse(textBox20.Text);
            import.Store_ID = int.Parse(textBox21.Text);
            import.Supplier_ID = int.Parse(textBox22.Text);
            import.Permission_Date = dateTimePicker3.Value;
            var AvailableId = (from i in Ent.ImportPermissions where i.ImpPermission_ID == import.ImpPermission_ID select i).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.ImportPermissions.Add(import);
                Ent.SaveChanges();
                Product_ImpPermission product_Imp = new Product_ImpPermission();

                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    product_Imp.ImpPermission_ID = int.Parse(textBox20.Text);
                    product_Imp.Product_Code = int.Parse(listView1.Items[i].SubItems[0].Text);
                    product_Imp.Product_Count = int.Parse(listView1.Items[i].SubItems[1].Text);
                    product_Imp.Production_Date = dateTimePicker4.Value;
                    product_Imp.Expire_Date = dateTimePicker5.Value;
                    Ent.Product_ImpPermission.Add(product_Imp);
                    Ent.SaveChanges();
                    Store_Products store_Products = (Ent.Store_Products.Where(s => s.Store_ID == import.Store_ID && s.Product_Code == product_Imp.Product_Code).Select(s => s)).FirstOrDefault();
                    if (store_Products != null)
                    {
                        ProductCount = (int)store_Products.ProductTotal_Count;
                        oldCount = ProductCount;
                        count.Add(oldCount);
                        //MessageBox.Show(ProductCount.ToString());
                        store_Products.ProductTotal_Count = ProductCount + int.Parse(listView1.Items[i].SubItems[1].Text);
                        //MessageBox.Show(ProductCount.ToString());
                        //MessageBox.Show(store_Products.ProductTotal_Count.ToString());
                        Ent.SaveChanges();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Data");
                    }
                }



                listView1.Items.Clear();
                comboBox5.Items.Clear();
                comboBox8.Items.Clear();
                textBox20.Text = textBox21.Text = textBox22.Text  = textBox26.Text = "";
                dateTimePicker3.Value = dateTimePicker4.Value = dateTimePicker5.Value = DateTime.Now;
                MessageBox.Show("Import Permission Added");
                comboBox5.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update import permission
        //update data field for this permission id including number of products to be imported and the tottal count of that product will be updated
        #endregion
        private void button10_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox20.Text);
            ImportPermission import = (Ent.ImportPermissions.Where(i => i.ImpPermission_ID == ID).Select(i => i)).FirstOrDefault();
            if (import != null)
            {
                import.Store_ID = int.Parse(textBox21.Text);
                import.Supplier_ID = int.Parse(textBox22.Text);
                import.Permission_Date = dateTimePicker3.Value;
                Ent.SaveChanges();
                Product_ImpPermission product_Imp = (Ent.Product_ImpPermission.Where(pi => pi.ImpPermission_ID == ID).Select(pi => pi)).FirstOrDefault();
                for(int i = 0; i < listView1.Items.Count; i++)
                {
                    if (product_Imp != null)
                    {
                        product_Imp.Product_Code = int.Parse(listView1.Items[i].SubItems[0].Text);
                        product_Imp.Product_Count = int.Parse(listView1.Items[i].SubItems[1].Text);
                        product_Imp.Production_Date = dateTimePicker4.Value;
                        product_Imp.Expire_Date = dateTimePicker5.Value;
                        Ent.SaveChanges();
                        Store_Products store_Products = (Ent.Store_Products.Where(s => s.Store_ID == import.Store_ID && s.Product_Code == product_Imp.Product_Code).Select(s => s)).FirstOrDefault();
                        if (store_Products != null)
                        {
                            ProductCount = count[i];
                            //MessageBox.Show(ProductCount.ToString());
                            store_Products.ProductTotal_Count = ProductCount + int.Parse(listView1.Items[i].SubItems[1].Text);
                            //MessageBox.Show(ProductCount.ToString());
                            //MessageBox.Show(store_Products.ProductTotal_Count.ToString());
                            Ent.SaveChanges();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Data");
                        }

                    }
                }

                listView1.Items.Clear();
                comboBox5.Items.Clear();
                comboBox8.Items.Clear();
                textBox20.Text = textBox21.Text = textBox22.Text   = textBox26.Text = "";
                dateTimePicker3.Value = dateTimePicker4.Value = dateTimePicker5.Value = DateTime.Now;
                MessageBox.Show("Import Permission Updated");
                comboBox4.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region export permission combobox
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ExportID = int.Parse(comboBox6.Text);
            ExportPermission export = Ent.ExportPermissions.Find(ExportID);
            if (export != null)
            {
                textBox29.Text = export.ExpPermission_ID.ToString();
                textBox30.Text = export.Store_ID.ToString();
                textBox31.Text = export.Supplier_ID.ToString();
                dateTimePicker6.Value = export.Permission_Date;
                Product_ExpPermission product_Exp = (Ent.Product_ExpPermission.Where(ex => ex.ExpPermission_ID == ExportID).Select(ex => ex)).FirstOrDefault();
                textBox34.Text = product_Exp.Product_Count.ToString();
            }
        }

        #region export product code combobox
        // when selected it shows the countity coursponding product
        #endregion
        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            int code = int.Parse(comboBox9.Text);
            int id = int.Parse(textBox30.Text);
            var count = (from store in Ent.ExportPermissions
                         from pc in Ent.Product_ExpPermission
                         where store.ExpPermission_ID == pc.ExpPermission_ID
                         where store.Store_ID == id
                         where pc.Product_Code == code
                         select pc.Product_Count).FirstOrDefault();
            textBox34.Text = count.ToString();
        }

        #region fillexport listview
        // fill listview with product code and its countity
        #endregion
        private void button17_Click(object sender, EventArgs e)
        {
            string[] arr = new string[10];
            ListViewItem item;
            //add items to ListView
            arr[0] = comboBox9.Text;
            arr[1] = textBox34.Text;
            item = new ListViewItem(arr);
            listView2.Items.Add(item);
        }

        #region add export permission
        //enter products in specific store with the desired countity the count number then will be subtracted to the total count of that product
        #endregion
        private void button11_Click(object sender, EventArgs e)
        {
            ExportPermission export = new ExportPermission();
            export.ExpPermission_ID = int.Parse(textBox29.Text);
            export.Store_ID = int.Parse(textBox30.Text);
            export.Supplier_ID = int.Parse(textBox31.Text);
            export.Permission_Date = dateTimePicker6.Value;
            var AvailableId = (from ex in Ent.ExportPermissions where ex.ExpPermission_ID == export.ExpPermission_ID select ex).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.ExportPermissions.Add(export);
                Ent.SaveChanges();
                Product_ExpPermission product_Exp = new Product_ExpPermission();
                for (int i = 0; i < listView2.Items.Count; i++)
                {
                    product_Exp.ExpPermission_ID = int.Parse(textBox29.Text);
                    product_Exp.Product_Code = int.Parse(listView2.Items[i].SubItems[0].Text);
                    product_Exp.Product_Count = int.Parse(listView2.Items[i].SubItems[1].Text);
                    Ent.Product_ExpPermission.Add(product_Exp);
                    Ent.SaveChanges();
                    Store_Products store_Products = (Ent.Store_Products.Where(s => s.Store_ID == export.Store_ID && s.Product_Code == product_Exp.Product_Code).Select(s => s)).FirstOrDefault();
                    if (store_Products != null)
                    {
                        //MessageBox.Show(ProductCount.ToString());
                        ProductCount = (int)store_Products.ProductTotal_Count;
                        oldCount = ProductCount;
                        count.Add(oldCount);
                        //MessageBox.Show(ProductCount.ToString());
                        store_Products.ProductTotal_Count = ProductCount - int.Parse(listView2.Items[i].SubItems[1].Text); ;
                        //MessageBox.Show(ProductCount.ToString());
                        //MessageBox.Show(store_Products.ProductTotal_Count.ToString());
                        Ent.SaveChanges();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Data");
                    }
                }
                listView2.Items.Clear();
                comboBox6.Items.Clear();
                comboBox9.Items.Clear();
                textBox29.Text = textBox30.Text = textBox31.Text  = textBox34.Text = "";
                dateTimePicker6.Value = DateTime.Now;
                MessageBox.Show("Export Permission Added");
                comboBox6.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region updateexport permission
        //update data field for this permission id including number of products to be imported and the tottal count of that product will be updated
        #endregion
        private void button12_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox29.Text);
            ExportPermission export = (Ent.ExportPermissions.Where(ex => ex.ExpPermission_ID== ID).Select(ex => ex)).FirstOrDefault();
            if (export != null)
            {
                export.Store_ID = int.Parse(textBox30.Text);
                export.Supplier_ID = int.Parse(textBox31.Text);
                export.Permission_Date = dateTimePicker6.Value;
                Ent.SaveChanges();
                Product_ExpPermission product_Exp = (Ent.Product_ExpPermission.Where(px => px.ExpPermission_ID == ID).Select(px => px)).FirstOrDefault();
               for(int i = 0; i < listView2.Items.Count; i++)
                {
                    if (product_Exp != null)
                    {
                        product_Exp.Product_Code = int.Parse(listView2.Items[i].SubItems[0].Text);
                        product_Exp.Product_Count = int.Parse(textBox34.Text);
                        Ent.SaveChanges();
                        Store_Products store_Products = (Ent.Store_Products.Where(s => s.Store_ID == export.Store_ID && s.Product_Code == product_Exp.Product_Code).Select(s => s)).FirstOrDefault();
                        if (store_Products != null)
                        {
                            ProductCount = count[i];
                            //MessageBox.Show(ProductCount.ToString());
                            store_Products.ProductTotal_Count = ProductCount - int.Parse(listView2.Items[i].SubItems[1].Text); ;
                            //MessageBox.Show(ProductCount.ToString());
                            //MessageBox.Show(store_Products.ProductTotal_Count.ToString());
                            Ent.SaveChanges();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Data");
                        }
                    }
                }
                listView2.Items.Clear();
                comboBox6.Items.Clear();
                comboBox9.Items.Clear();
                textBox29.Text = textBox30.Text = textBox31.Text  = textBox34.Text = "";
                dateTimePicker6.Value = DateTime.Now;
                MessageBox.Show("Export Permission Updated");
                comboBox6.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region transfer permission combobox
        // when selecting item in combobox it feels the data in controllors with values coresponding to product name
        #endregion
        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            int TransferID = int.Parse(comboBox7.Text);
            ProductTransfer transfer = Ent.ProductTransfers.Find(TransferID);
            if (transfer != null)
            {
                textBox38.Text = transfer.Transfer_ID.ToString();
                textBox39.Text = transfer.FromStore_ID.ToString();
                textBox40.Text = transfer.ToStore_ID.ToString();
                textBox41.Text = transfer.Supplier_ID.ToString();
                textBox42.Text = transfer.Product_Code.ToString();
                textBox43.Text = transfer.Product_Count.ToString();
                dateTimePicker7.Value = transfer.Production_Date;
                dateTimePicker8.Value = transfer.Expire_Date;
                dateTimePicker9.Value = transfer.Transfer_Date;
            }
        }

        #region add transfer permission
        // you ca add transfer permission on item from store to another and specify the count of the producted to be transfered 
        // the total count in the from store will be subtracted and added to the to store
        #endregion
        private void button13_Click(object sender, EventArgs e)
        {
            ProductTransfer transfer = new ProductTransfer();
            transfer.Transfer_ID = int.Parse(textBox38.Text);
            transfer.FromStore_ID = int.Parse(textBox39.Text);
            transfer.ToStore_ID = int.Parse(textBox40.Text);
            transfer.Supplier_ID = int.Parse(textBox41.Text);
            transfer.Product_Code= int.Parse(textBox42.Text);
            transfer.Product_Count = int.Parse(textBox43.Text);
            transfer.Production_Date = dateTimePicker7.Value;
            transfer.Expire_Date = dateTimePicker8.Value;
            transfer.Transfer_Date = dateTimePicker9.Value;
            var AvailableId = (from t in Ent.ProductTransfers where t.Transfer_ID == transfer.Transfer_ID select t).FirstOrDefault();
            if (AvailableId == null)
            {
                Ent.ProductTransfers.Add(transfer);
                Ent.SaveChanges();
                Store_Products from_store_Products = (Ent.Store_Products.Where(s => s.Store_ID == transfer.FromStore_ID && s.Product_Code == transfer.Product_Code).Select(s => s)).FirstOrDefault();
                if (from_store_Products != null)
                {
                    //MessageBox.Show(ProductCount.ToString());
                    ProductCount = (int)from_store_Products.ProductTotal_Count;
                    fromCount = ProductCount;
                    //MessageBox.Show(ProductCount.ToString());
                    from_store_Products.ProductTotal_Count = ProductCount - int.Parse(textBox43.Text);
                    //MessageBox.Show(ProductCount.ToString());
                    //MessageBox.Show(from_store_Products.ProductTotal_Count.ToString());
                    Ent.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Invalid Data");
                }
                Store_Products to_store_Products = (Ent.Store_Products.Where(s => s.Store_ID == transfer.ToStore_ID && s.Product_Code == transfer.Product_Code).Select(s => s)).FirstOrDefault();
                if (to_store_Products != null)
                {
                    MessageBox.Show(ProductCount.ToString());
                    ProductCount = (int)to_store_Products.ProductTotal_Count;
                    toCount = ProductCount;
                    MessageBox.Show(ProductCount.ToString());
                    to_store_Products.ProductTotal_Count = ProductCount + int.Parse(textBox43.Text);
                    MessageBox.Show(ProductCount.ToString());
                    MessageBox.Show(to_store_Products.ProductTotal_Count.ToString());
                    Ent.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Invalid Data");
                }
                textBox38.Text = textBox39.Text = textBox40.Text = textBox41.Text = textBox42.Text = textBox43.Text = "";
                dateTimePicker7.Value = dateTimePicker7.Value = DateTime.Now;
                MessageBox.Show("Product Transfer Added");
                comboBox7.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region update transfer permission
        // you can change any values in this primary key including the count and it will be updated in the product total count in the from and to store
        #endregion
        private void button14_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox38.Text);
            ProductTransfer transfer = (Ent.ProductTransfers.Where(t => t.Transfer_ID == ID).Select(t => t)).FirstOrDefault();
            if (transfer != null)
            {
                transfer.FromStore_ID = int.Parse(textBox39.Text);
                transfer.ToStore_ID = int.Parse(textBox40.Text);
                transfer.Supplier_ID = int.Parse(textBox41.Text);
                transfer.Product_Code = int.Parse(textBox42.Text);
                transfer.Product_Count = int.Parse(textBox43.Text);
                transfer.Production_Date = dateTimePicker7.Value;
                transfer.Expire_Date = dateTimePicker8.Value;
                transfer.Transfer_Date = dateTimePicker9.Value;
                Ent.SaveChanges();
                Store_Products from_store_Products = (Ent.Store_Products.Where(s => s.Store_ID == transfer.FromStore_ID && s.Product_Code == transfer.Product_Code).Select(s => s)).FirstOrDefault();
                if (from_store_Products != null)
                {
                    //MessageBox.Show(ProductCount.ToString());
                    ProductCount = fromCount;
                    //MessageBox.Show(ProductCount.ToString());
                    from_store_Products.ProductTotal_Count = ProductCount - int.Parse(textBox43.Text);
                    //MessageBox.Show(ProductCount.ToString());
                    //MessageBox.Show(from_store_Products.ProductTotal_Count.ToString());
                    Ent.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Invalid Data");
                }
                Store_Products to_store_Products = (Ent.Store_Products.Where(s => s.Store_ID == transfer.ToStore_ID && s.Product_Code == transfer.Product_Code).Select(s => s)).FirstOrDefault();
                if (to_store_Products != null)
                {
                    //MessageBox.Show(ProductCount.ToString());
                    ProductCount = toCount;
                    MessageBox.Show(ProductCount.ToString());
                    to_store_Products.ProductTotal_Count = ProductCount + int.Parse(textBox43.Text);
                    MessageBox.Show(ProductCount.ToString());
                    MessageBox.Show(to_store_Products.ProductTotal_Count.ToString());
                    Ent.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Invalid Data");
                }
                textBox38.Text = textBox39.Text = textBox40.Text = textBox41.Text = textBox42.Text = textBox43.Text = "";
                dateTimePicker7.Value = dateTimePicker7.Value = DateTime.Now;
                MessageBox.Show("Product Transfer Updated");
                comboBox6.Items.Clear();
                UpdateComboBox();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }

        #region button to transfer to report form
        #endregion
        private void button15_Click(object sender, EventArgs e)
        {
            Reports reports = new Reports();
            reports.Show();
        }
    }
    
}
