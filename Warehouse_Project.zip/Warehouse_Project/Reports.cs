﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Warehouse_Project
{
    public partial class Reports : Form
    {
        EFModel Ent = new EFModel();
        public Reports()
        {
            InitializeComponent();
            UpdateComboBox();
        }

        #region update ComboBox
        //update combobox for each point in the task
        #endregion
        public void UpdateComboBox()
        {
            //first report
            var store = from s in Ent.Stores
                        select s.Store_Name;
            foreach (var st in store)
            {
                comboBox1.Items.Add(st);
            }

            var productCode = from p in Ent.Products
                        select p.Product_Name;
            foreach (var pr in productCode)
            {
                //second report
                comboBox2.Items.Add(pr);
                ////fourth report
                comboBox4.Items.Add(pr);
                //fifth report
                comboBox6.Items.Add(pr);
                //third report
                comboBox8.Items.Add(pr);
            }

            var storeID = from st in Ent.Stores
                          select st.Store_ID;
            foreach (var st in storeID)
            {
                comboBox9.Items.Add(st);
                comboBox10.Items.Add(st);
            }
        }

        #region report 1 combobox
        //fill controls with dara coresponding to product 
        #endregion
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = comboBox1.Text;
            var store = Ent.Stores.Where(s => s.Store_Name == name).Select(s => s.Store_ID).FirstOrDefault();
            textBox1.Text = store.ToString();

        }

        #region report 1
            //generate report that displays store data
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox1.Text);
            DateTime Production = dateTimePicker1.Value;
            DateTime Expire = dateTimePicker2.Value;
            var store = from storee in Ent.Stores 
                        from product in Ent.Products
                        from sp in Ent.Store_Products
                        where storee.Store_ID == sp.Store_ID
                        where product.Product_Code == sp.Product_Code
                        where storee.Store_ID == ID
                        where product.Production_Date >= Production && product.Expire_Date <= Expire
                        select new
                        {
                            ID = storee.Store_ID,
                            Store_Name  = storee.Store_Name,
                            Store_Address = storee.Store_Add,
                            Store_Manager = storee.Store_Manager,
                            Product_Code = product.Product_Code,
                            Product_name = product.Product_Name,
                            Product_Production_Date = product.Production_Date,
                            Product_Expiration_Date = product.Expire_Date
                        };
            dataGridView1.DataSource = store.ToList();
        }

   
        #region report 2 combobox
        //fill controls with dara coresponding to product 
        #endregion
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID = int.Parse(comboBox3.Text);
            listBox1.Items.Add(ID);
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            listBox1.Items.Clear();
            string name = comboBox2.Text;
            var product = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            var store = Ent.Store_Products.Where(sp => sp.Product_Code == product).Select(sp => sp.Store_ID);

            foreach (var item in store)
            {
                comboBox3.Items.Add(item);
            }

            var ProductCode = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            textBox2.Text = ProductCode.ToString();

        }

        #region product class
        // class with the properties of the data that will be shown when generate the report
        #endregion
        public class ProductReport2
        {
            public int ID { set; get; }
            public string Store_Name { set; get; }
            public string Store_Address { set; get; }
            public string Store_Manager { set; get; }
            public int Product_Code { set; get; }
            public string Product_name { set; get; }
            public string Product_Measure { set; get; }
            public DateTime Product_Production_Date { set; get; }
            public DateTime Product_Expiration_Date { set; get; }
        }

        #region report 2
        // the report shows the data of the product depending on which warehouses you want and if you didnt choose warehouse it will show all the stores
        // where this product is available between the choosen date
        #endregion
        private void button2_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox2.Text);
            DateTime Production = dateTimePicker3.Value;
            DateTime Expire = dateTimePicker4.Value;
            List<ProductReport2> list = new List<ProductReport2>() { };
            if(listBox1.Items.Count != 0)
            {
                foreach (int item in listBox1.Items)
                {
                    var productt = (from storee in Ent.Stores
                                   from product in Ent.Products
                                   from sp in Ent.Store_Products
                                   from measure in Ent.ItemMeasurements
                                   where storee.Store_ID == sp.Store_ID
                                   where product.Product_Code == sp.Product_Code
                                   where measure.Product_Code == product.Product_Code
                                   where storee.Store_ID == item
                                   where product.Product_Code == ID
                                   where measure.Product_Code == ID
                                   where product.Production_Date >= Production && product.Expire_Date <= Expire
                                   select new ProductReport2
                                   {
                                       ID = storee.Store_ID,
                                       Store_Name = storee.Store_Name,
                                       Store_Address = storee.Store_Add,
                                       Store_Manager = storee.Store_Manager,
                                       Product_Code = product.Product_Code,
                                       Product_name = product.Product_Name,
                                       Product_Measure = measure.Measure,
                                       Product_Production_Date = product.Production_Date,
                                       Product_Expiration_Date = product.Expire_Date
                                   }).FirstOrDefault();

                    list.Add((ProductReport2)productt);

                }
                dataGridView2.DataSource =list;
            }
            else
            {
                var productt = from storee in Ent.Stores
                               from product in Ent.Products
                               from sp in Ent.Store_Products
                               where storee.Store_ID == sp.Store_ID
                               where product.Product_Code == sp.Product_Code
                               where product.Product_Code == ID
                               where product.Production_Date >= Production && product.Expire_Date <= Expire
                               select new
                               {
                                   ID = storee.Store_ID,
                                   Store_Name = storee.Store_Name,
                                   Store_Address = storee.Store_Add,
                                   Store_Manager = storee.Store_Manager,
                                   Product_Code = product.Product_Code,
                                   Product_name = product.Product_Name,
                                   Product_Production_Date = product.Production_Date,
                                   Product_Expiration_Date = product.Expire_Date
                               };
                dataGridView2.DataSource = productt.ToList();
            }
        }

        #region report 3 combobox
        //fill controls with dara coresponding to product 
        #endregion
        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox9.Items.Clear();
            listBox2.Items.Clear();
            string name = comboBox8.Text;
            var product = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            var store = Ent.Store_Products.Where(sp => sp.Product_Code == product).Select(sp => sp.Store_ID);

            foreach (var item in store)
            {
                comboBox9.Items.Add(item);
            }

            var ProductCode = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            textBox5.Text = ProductCode.ToString();
        }
        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID = int.Parse(comboBox9.Text);
            listBox2.Items.Add(ID);
        }

        #region transfer class
        // class with the properties of the data that will be shown when generate the report
        #endregion
        public class TransferReport3
        {
            public int Transfer_ID { set; get; }
            public int From_Store_ID { set; get; }
            public int To_Store_ID { set; get; }
            public int? Supplier_ID { set; get; }
            public int Product_Code { set; get; }
            public int? Product_Count { set; get; }
            public DateTime Product_Production_Date { set; get; }
            public DateTime Product_Expiration_Date { set; get; }
            public DateTime Transfer_Date { set; get; }
        }

        #region report 3
            // the report will generate data for transfer table between the stores the user will choose
            // in the choosen date
        #endregion
        private void button5_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox5.Text);
            DateTime FromDate = dateTimePicker5.Value;
            DateTime ToDate = dateTimePicker6.Value;
            List<TransferReport3> list = new List<TransferReport3>() { };
            if (listBox2.Items.Count != 0)
            {
                int fromId = int.Parse(comboBox9.Text);
                foreach (int item in listBox2.Items)
                {
                    var productt = (from transfer in Ent.ProductTransfers
                                    from fromStore in Ent.Stores
                                    from toStore in Ent.Stores
                                    where fromStore.Store_ID == transfer.FromStore_ID
                                    where toStore.Store_ID == transfer.ToStore_ID
                                    where transfer.Product_Code == ID
                                    where transfer.FromStore_ID == item
                                    where transfer.ToStore_ID == fromId
                                    where transfer.Transfer_Date >= FromDate && transfer.Transfer_Date <= ToDate
                                    select new TransferReport3
                                    {
                                        Transfer_ID = transfer.Transfer_ID,
                                        From_Store_ID = item,
                                        To_Store_ID = fromId,
                                        Supplier_ID = transfer.Supplier_ID,
                                        Product_Code = (int)transfer.Product_Code,
                                        Product_Count = transfer.Product_Count,
                                        Product_Production_Date = transfer.Production_Date,
                                        Product_Expiration_Date = transfer.Expire_Date,
                                        Transfer_Date = transfer.Transfer_Date
                                    }).FirstOrDefault();


                    list.Add((TransferReport3)productt);

                }
                dataGridView5.DataSource = list;
            }
            else
            {
                var productt = from transfer in Ent.ProductTransfers
                               from fromStore in Ent.Stores
                               from toStore in Ent.Stores
                               where fromStore.Store_ID == transfer.FromStore_ID
                               where toStore.Store_ID == transfer.ToStore_ID
                               where transfer.Product_Code == ID
                               where transfer.Transfer_Date >= FromDate && transfer.Transfer_Date <= ToDate
                               select new
                               {
                                   Transfer_ID = transfer.Transfer_ID,
                                   From_Store_ID = transfer.FromStore_ID,
                                   To_Store_ID = transfer.ToStore_ID,
                                   Supplier_ID = transfer.Supplier_ID,
                                   Product_Code = (int)transfer.Product_Code,
                                   Product_Count = transfer.Product_Count,
                                   Product_Production_Date = transfer.Production_Date,
                                   Product_Expiration_Date = transfer.Expire_Date,
                                   Transfer_Date = transfer.Transfer_Date
                               };
                dataGridView5.DataSource = productt.ToList();
            }
        }

        #region report4 combobox
        //fill controls with dara coresponding to product 
        #endregion
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = comboBox4.Text;
            var ProductCode = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            textBox3.Text = ProductCode.ToString();
        }

        #region report 4
            // the report will show the products that has been in specific store within the choosen period in months
        #endregion
        private void button3_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox3.Text);
            DateTime Production = dateTimePicker3.Value;
            DateTime Expire = dateTimePicker4.Value;
            double months = double.Parse( comboBox5.Text);
            if(comboBox10.SelectedIndex != 0)
            {
                int storeId = int.Parse(comboBox10.Text);
                var productt = from import in Ent.ImportPermissions
                               from product in Ent.Products
                               from pi in Ent.Product_ImpPermission
                               where import.ImpPermission_ID == pi.ImpPermission_ID
                               where product.Product_Code == pi.Product_Code
                               where product.Product_Code == ID
                               where import.Store_ID == storeId
                               where EntityFunctions.DiffMonths(DateTime.Now, import.Permission_Date) <= months
                               select new
                               {
                                   Product_Code = product.Product_Code,
                                   Product_name = product.Product_Name,
                                   Product_Production_Date = product.Production_Date,
                                   Product_Expiration_Date = product.Expire_Date,
                                   Store_ID = import.Store_ID,
                                   Permission_Date = import.Permission_Date
                               };
                dataGridView3.DataSource = productt.ToList();
            }
            else
            {
                var productt = from import in Ent.ImportPermissions
                               from product in Ent.Products
                               from pi in Ent.Product_ImpPermission
                               where import.ImpPermission_ID == pi.ImpPermission_ID
                               where product.Product_Code == pi.Product_Code
                               where product.Product_Code == ID
                               where EntityFunctions.DiffMonths(DateTime.Now, import.Permission_Date) <= months
                               select new
                               {
                                   Product_Code = product.Product_Code,
                                   Product_name = product.Product_Name,
                                   Product_Production_Date = product.Production_Date,
                                   Product_Expiration_Date = product.Expire_Date,
                                   Store_ID = import.Store_ID,
                                   Permission_Date = import.Permission_Date
                               };
                dataGridView3.DataSource = productt.ToList();
            }

        }

        #region report5 combobox
        //fill controls with dara coresponding to product 
        #endregion
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = comboBox6.Text;
            var ProductCode = Ent.Products.Where(p => p.Product_Name == name).Select(p => p.Product_Code).FirstOrDefault();
            textBox4.Text = ProductCode.ToString();
        }

        #region report 5
            // the report will show the products that there expiration da te is less than or equal the chosen perion in months
        #endregion
        private void button4_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(textBox4.Text);
            DateTime Production = dateTimePicker3.Value;
            DateTime Expire = dateTimePicker4.Value;
            double months = double.Parse(comboBox7.Text);
            var productt = from import in Ent.ImportPermissions
                           from product in Ent.Products
                           from pi in Ent.Product_ImpPermission
                           where import.ImpPermission_ID == pi.ImpPermission_ID
                           where product.Product_Code == pi.Product_Code
                           where product.Product_Code == ID
                           where EntityFunctions.DiffMonths(DateTime.Now, product.Expire_Date) <= months
                           select new
                           {
                               Product_Code = product.Product_Code,
                               Product_name = product.Product_Name,
                               Product_Production_Date = product.Production_Date,
                               Product_Expiration_Date = product.Expire_Date,
                               Store_ID = import.Store_ID,
                               Permission_Date = import.Permission_Date
                           };
            dataGridView4.DataSource = productt.ToList();
        }

    }
}
